# Sistem Informasi Data Mahasiswa STSN Dengan LARAVEL
# cara Instalasi
1. download filenya atau bisa di clone. letakan ke directory.
2.    lakukan composer install atau composer update.
3.       setelah proses selesai. lakukan migration dan seed.
4.          lihat juga relasi tabelnya di file migration.
5.             atau dapat dibuat sendiri => kelas.wali_kls --> Dosen.id && Mahasiswa.wali_kls --> gurus.id .
6.                anda bisa melakukan php artisan serve.
7.                   akses via browser dengan url http://localhost:8000


# Fitur
1. Login Data Admin Dan User
2. Tambah Data, Hapus Data Dan Update Data
3. Tabel Data Mahasiswa Dan Tabel Nilai Mahasiswa
# Login
ADMIN<br />
Username : admin<br />
Password : admin123<br />

USER<br />
Username : fikri<br />
Password : fikri123<br />

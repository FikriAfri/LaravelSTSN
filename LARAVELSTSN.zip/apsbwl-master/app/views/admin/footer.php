	<script>
	$('.datepicker').datepicker({
		format: 'yyyy-mm-dd',
	})
	</script>
</body>
</html>